import type { ReactNode } from "react";

interface Props {
  src: string;
  alt: string;
  caption?: string;
  index?: string;
  aspect?: string;
  priority?: boolean;
  children?: ReactNode;
  className?: string;
  imageClassName?: string;
}

export function EngravingFrame({
  src,
  alt,
  caption,
  index,
  aspect = "16 / 10",
  priority = false,
  children,
  className = "",
  imageClassName = "",
}: Props) {
  return (
    <figure className={`relative ${className}`}>
      <div className="relative overflow-hidden border border-border bg-cream-deep">
        <div style={{ aspectRatio: aspect }} className="relative w-full overflow-hidden">
          <img
            src={src}
            alt={alt}
            loading={priority ? "eager" : "lazy"}
            decoding="async"
            className={`absolute inset-0 h-full w-full object-cover ${imageClassName}`}
          />
          {/* warm tint to keep palette unified */}
          <div className="pointer-events-none absolute inset-0 mix-blend-multiply"
               style={{ background: "linear-gradient(to bottom, color-mix(in oklab, var(--cream) 12%, transparent), transparent 30%, color-mix(in oklab, var(--cream) 18%, transparent))" }} />
          {children}
        </div>
        {/* internal hairline frame */}
        <div className="pointer-events-none absolute inset-2 border border-bronze/25" />
      </div>
      {(caption || index) && (
        <figcaption className="mt-3 flex items-baseline justify-between text-[0.7rem] uppercase tracking-[0.18em] text-muted-foreground">
          {caption && <span className="font-serif italic normal-case tracking-normal text-[0.85rem] text-muted-foreground">{caption}</span>}
          {index && <span className="text-bronze">{index}</span>}
        </figcaption>
      )}
    </figure>
  );
}
