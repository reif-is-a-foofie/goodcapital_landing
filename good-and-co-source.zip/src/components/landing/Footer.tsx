import logoDark from "@/assets/logo-dark.png";

export function Footer() {
  return (
    <footer className="hairline-top bg-cream-deep">
      <div className="mx-auto max-w-[1320px] px-6 py-20 md:px-10">
        <div className="grid gap-12 md:grid-cols-12">
          <div className="md:col-span-5">
            <img src={logoDark} alt="Good + Co." className="h-9 w-auto" />
            <p className="mt-6 max-w-sm font-serif text-[1.05rem] italic leading-relaxed text-muted-foreground">
              A project of The Good Project. Helping owners prepare for
              transitions with clarity, operational strength, and long-term
              alignment.
            </p>
          </div>

          <div className="md:col-span-3">
            <p className="eyebrow mb-5">Practice</p>
            <ul className="space-y-2 text-charcoal/85">
              <li><a href="#why" className="hover:text-bronze">Why Ready Matters</a></li>
              <li><a href="#meet" className="hover:text-bronze">Meet Reif</a></li>
              <li><a href="#readiness" className="hover:text-bronze">Readiness</a></li>
              <li><a href="#mission" className="hover:text-bronze">Mission</a></li>
            </ul>
          </div>

          <div className="md:col-span-4">
            <p className="eyebrow mb-5">Inquiries</p>
            <a
              href="mailto:hello@goodandco.com"
              className="font-serif text-2xl text-charcoal hover:text-bronze"
            >
              hello@goodandco.com
            </a>
            <p className="mt-3 text-sm text-muted-foreground">
              By appointment. We respond within two business days.
            </p>
          </div>
        </div>

        <div className="mt-16 flex flex-col items-start justify-between gap-3 border-t border-border pt-6 text-[0.72rem] uppercase tracking-[0.2em] text-muted-foreground md:flex-row md:items-center">
          <span>© {new Date().getFullYear()} Good + Co.</span>
          <span className="font-serif normal-case tracking-normal">
            Lat. 41° 32′ N · Lon. 70° 40′ W
          </span>
          <span>Est. with care</span>
        </div>
      </div>
    </footer>
  );
}
