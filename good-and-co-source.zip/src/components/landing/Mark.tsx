export function Mark({ className = "" }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 40 40"
      className={className}
      fill="none"
      stroke="currentColor"
      strokeWidth="1"
      aria-hidden="true"
    >
      <circle cx="20" cy="20" r="18" />
      <line x1="20" y1="2" x2="20" y2="38" />
      <line x1="2" y1="20" x2="38" y2="20" />
      <circle cx="20" cy="20" r="9" />
      <circle cx="20" cy="20" r="2" fill="currentColor" />
    </svg>
  );
}
