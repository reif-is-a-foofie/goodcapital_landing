import { useEffect, useState } from "react";
import logoDark from "@/assets/logo-dark.png";

const NAV = [
  { label: "Why Ready Matters", href: "#why" },
  { label: "Meet Reif", href: "#meet" },
  { label: "Readiness", href: "#readiness" },
  { label: "Mission", href: "#mission" },
  { label: "Talk With Us", href: "#contact" },
];

export function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-colors duration-500 ${
        scrolled
          ? "bg-cream/85 backdrop-blur-sm hairline-bottom"
          : "bg-transparent"
      }`}
    >
      <div className="mx-auto flex max-w-[1320px] items-center justify-between px-6 py-5 md:px-10">
        <a href="#top" className="flex items-center gap-3 text-charcoal">
          <img
            src={scrolled ? logoDark : logoDark}
            alt="Good + Co."
            className="h-7 w-auto md:h-8"
          />
          <span className="sr-only">Good + Co.</span>
        </a>

        <nav className="hidden items-center gap-8 lg:flex">
          {NAV.map((n) => (
            <a
              key={n.href}
              href={n.href}
              className="text-[0.78rem] uppercase tracking-[0.2em] text-charcoal/75 transition-colors hover:text-bronze"
            >
              {n.label}
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          <a
            href="#contact"
            className="hidden items-center gap-2 border border-charcoal/80 px-5 py-2.5 text-[0.72rem] uppercase tracking-[0.22em] text-charcoal transition-all hover:bg-charcoal hover:text-cream md:inline-flex"
          >
            Start a Conversation
            <span className="text-bronze">→</span>
          </a>
          <button
            onClick={() => setOpen((v) => !v)}
            className="lg:hidden flex h-9 w-9 items-center justify-center border border-border"
            aria-label="Open menu"
          >
            <span className="sr-only">Menu</span>
            <div className="space-y-1.5">
              <span className="block h-px w-5 bg-charcoal" />
              <span className="block h-px w-5 bg-charcoal" />
            </div>
          </button>
        </div>
      </div>

      {open && (
        <div className="lg:hidden bg-cream hairline-top">
          <div className="mx-auto flex max-w-[1320px] flex-col gap-4 px-6 py-6">
            {NAV.map((n) => (
              <a
                key={n.href}
                href={n.href}
                onClick={() => setOpen(false)}
                className="text-sm uppercase tracking-[0.18em] text-charcoal/80"
              >
                {n.label}
              </a>
            ))}
            <a
              href="#contact"
              onClick={() => setOpen(false)}
              className="mt-2 inline-flex w-fit items-center gap-2 border border-charcoal px-5 py-3 text-[0.72rem] uppercase tracking-[0.22em] text-charcoal"
            >
              Start a Conversation <span className="text-bronze">→</span>
            </a>
          </div>
        </div>
      )}
    </header>
  );
}
