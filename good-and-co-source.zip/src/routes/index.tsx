import { createFileRoute } from "@tanstack/react-router";
import { motion, useScroll, useTransform } from "framer-motion";
import { useRef } from "react";

import { Header } from "@/components/landing/Header";
import { Footer } from "@/components/landing/Footer";
import { Reveal } from "@/components/landing/Reveal";
import { EngravingFrame } from "@/components/landing/EngravingFrame";

import heroImg from "@/assets/hero-lighthouse.jpg";
import depthChartImg from "@/assets/depth-chart.jpg";
import shipImg from "@/assets/merchant-ship.jpg";
import reifPortrait from "@/assets/reif-portrait.jpg";
import safePassageImg from "@/assets/safe-passage.jpg";
import harborImg from "@/assets/harbor-sunrise.jpg";
import townImg from "@/assets/coastal-town.jpg";
import beamImg from "@/assets/beam-abstract.jpg";

export const Route = createFileRoute("/")({
  component: Index,
});

function Index() {
  return (
    <div id="top" className="min-h-screen bg-cream text-charcoal">
      <Header />
      <main>
        <Hero />
        <Problem />
        <WhoWeWorkWith />
        <MeetReif />
        <Readiness />
        <HumanTransition />
        <Mission />
        <FinalCTA />
      </main>
      <Footer />
    </div>
  );
}

/* ---------- Section: Hero ---------- */

function Hero() {
  const ref = useRef<HTMLDivElement | null>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const y = useTransform(scrollYProgress, [0, 1], ["0%", "12%"]);
  const opacity = useTransform(scrollYProgress, [0, 1], [1, 0.4]);

  return (
    <section ref={ref} className="relative overflow-hidden pt-32 md:pt-36">
      {/* coordinate badge */}
      <div className="absolute left-6 top-24 hidden text-[0.65rem] uppercase tracking-[0.3em] text-muted-foreground md:block md:left-10">
        <div>Vol. I</div>
        <div className="mt-1 text-bronze">№ 001</div>
      </div>
      <div className="absolute right-6 top-24 hidden text-right text-[0.65rem] uppercase tracking-[0.3em] text-muted-foreground md:block md:right-10">
        <div>A Journal of</div>
        <div className="mt-1">Safe Passage</div>
      </div>

      <div className="mx-auto max-w-[1320px] px-6 md:px-10">
        <Reveal>
          <p className="eyebrow text-center md:text-left">
            Opening
          </p>
        </Reveal>

        <Reveal delay={0.1}>
          <h1 className="mt-8 max-w-5xl font-serif text-[2.6rem] leading-[1.05] tracking-[-0.02em] text-charcoal sm:text-[3.4rem] md:text-[4.6rem] lg:text-[5.4rem]">
            You built something real. <br className="hidden sm:block" />
            Now you&rsquo;re trying to figure out{" "}
            <span className="italic text-bronze/95">what comes next.</span>
          </h1>
        </Reveal>

        <Reveal delay={0.2}>
          <p className="mt-8 max-w-2xl font-serif text-xl italic text-muted-foreground md:text-2xl">
            Most owners at this stage aren&rsquo;t worried about finding a buyer.
            They&rsquo;re worried about what happens after.
          </p>
        </Reveal>

        {/* hero image */}
        <Reveal delay={0.3}>
          <motion.div
            style={{ y, opacity }}
            className="relative mt-16 grid grid-cols-12 gap-6"
          >
            <div className="col-span-12 lg:col-span-9">
              <EngravingFrame
                src={heroImg}
                imageClassName="drift-water"
                alt="A distant lighthouse in fog at dawn, a thin beam cutting through the mist"
                aspect="16 / 9"
                priority
                index="Plate I · Landfall"
                caption="Distant light, observed at first watch."
              />
            </div>

            <div className="col-span-12 lg:col-span-3 lg:pl-2">
              <div className="hairline-top pt-6 lg:border-t-0 lg:hairline-top">
                <p className="font-serif text-[1.05rem] leading-relaxed text-charcoal">
                  Whether the people you built this with will be taken care of.
                  Whether you&rsquo;ll still have a reason to get up in the
                  morning. Whether whoever you hand this to will deserve it.
                  Those aren&rsquo;t financial questions. But they shape every
                  financial decision you&rsquo;ll make.
                </p>
                <div className="mt-8 flex flex-col gap-3">
                  <a
                    href="#contact"
                    className="group inline-flex items-center justify-between gap-4 bg-charcoal px-6 py-4 text-[0.72rem] uppercase tracking-[0.22em] text-cream transition-colors hover:bg-ink"
                  >
                    Start a conversation
                    <span className="text-bronze-soft transition-transform group-hover:translate-x-1">→</span>
                  </a>
                  <a
                    href="#readiness"
                    className="inline-flex items-center justify-between gap-4 border border-charcoal/30 px-6 py-4 text-[0.72rem] uppercase tracking-[0.22em] text-charcoal hover:border-charcoal"
                  >
                    How we work
                    <span className="text-bronze">↓</span>
                  </a>
                </div>
              </div>
            </div>
          </motion.div>
        </Reveal>

        <Reveal delay={0.45}>
          <div className="mt-16 flex items-center gap-4">
            <div className="h-px w-12 bg-bronze" />
            <p className="font-serif text-[1.05rem] italic text-muted-foreground">
              The chapter after this one should be one you actually want to live.
            </p>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

/* ---------- Section: Problem ---------- */

function Problem() {
  const steps = [
    "Know what you have",
    "Know what it’s worth",
    "Know who should own it next",
    "Know what you need from the deal",
  ];
  return (
    <section id="why" className="relative mt-40 md:mt-56">
      <div className="map-grid absolute inset-0 opacity-50" aria-hidden="true" />
      <div className="relative mx-auto max-w-[1320px] px-6 md:px-10">
        <div className="grid grid-cols-12 gap-10">
          <div className="col-span-12 lg:col-span-5">
            <Reveal>
              <p className="eyebrow">№ 002 · The Approach</p>
            </Reveal>
            <Reveal delay={0.1}>
              <h2 className="mt-6 font-serif text-[2.2rem] leading-[1.1] tracking-tight text-charcoal sm:text-[2.8rem] md:text-[3.4rem]">
                The buyers who show up first are <em className="text-bronze">rarely the right ones.</em>
              </h2>
            </Reveal>
          </div>

          <div className="col-span-12 lg:col-span-6 lg:col-start-7">
            <Reveal delay={0.15}>
              <p className="font-serif text-2xl leading-snug text-charcoal">
                The owners who keep it are the ones who prepared before anyone called.
              </p>
            </Reveal>
            <Reveal delay={0.25}>
              <div className="mt-8 space-y-5 text-[1.05rem] leading-relaxed text-charcoal/85">
                <p>
                  When you&rsquo;ve spent twenty or thirty years building
                  something, the process moves faster than you expect. The
                  pressure is real. And most owners, by the time they&rsquo;re
                  inside a formal transaction, have already given up leverage
                  they didn&rsquo;t know they had.
                </p>
                <p className="text-muted-foreground">
                  Knowing what you have, what it&rsquo;s worth, and what you
                  need from the deal takes time. That kind of clarity changes
                  everything.
                </p>
              </div>
            </Reveal>
          </div>
        </div>

        {/* depth chart */}
        <Reveal delay={0.2}>
          <div className="mt-20">
            <EngravingFrame
              src={depthChartImg}
              alt="A 19th-century depth chart showing hidden rocks and a marked safe channel"
              aspect="21 / 9"
              caption="Hazards remain whether the chart shows them or not."
              index="Plate II · Soundings"
            />
          </div>
        </Reveal>

        {/* 4-step */}
        <div className="mt-24 hairline-top pt-12">
          <Reveal>
            <p className="eyebrow mb-8">Prepared, before the call</p>
          </Reveal>
          <ol className="grid grid-cols-1 gap-6 md:grid-cols-4">
            {steps.map((s, i) => (
              <Reveal key={s} delay={i * 0.08}>
                <li className="relative">
                  <div className="flex items-baseline gap-3">
                    <span className="font-serif text-[0.85rem] italic text-bronze">
                      {String(i + 1).padStart(2, "0")}
                    </span>
                    <div className="h-px flex-1 bg-border" />
                    {i < steps.length - 1 && (
                      <span className="hidden text-bronze/60 md:inline">→</span>
                    )}
                  </div>
                  <p className="mt-4 font-serif text-[1.4rem] leading-snug text-charcoal">
                    {s}
                  </p>
                </li>
              </Reveal>
            ))}
          </ol>
        </div>
      </div>
    </section>
  );
}

/* ---------- Section: Who We Work With ---------- */

function WhoWeWorkWith() {
  const items = [
    "Built a real operating company",
    "Want to leave it better than they found it",
    "Care about their employees and customers",
    "Considering a transition, or already running one",
    "Would rather hear a hard truth in March than a comfortable one in September",
  ];
  return (
    <section className="relative mt-40 md:mt-56">
      <div className="mx-auto max-w-[1320px] px-6 md:px-10">
        <div className="grid grid-cols-12 gap-10 lg:gap-16">
          <div className="col-span-12 lg:col-span-7">
            <Reveal>
              <EngravingFrame
                src={shipImg}
                imageClassName="drift-water"
                alt="A weathered merchant ship crossing open calm water"
                aspect="16 / 11"
                caption="A working vessel underway. Functional, not ornamental."
                index="Plate III · The Vessel"
              />
            </Reveal>
          </div>

          <div className="col-span-12 lg:col-span-5">
            <Reveal>
              <p className="eyebrow">№ 003 · Who We Work With</p>
            </Reveal>
            <Reveal delay={0.1}>
              <h2 className="mt-6 font-serif text-[2.2rem] leading-[1.05] tracking-tight text-charcoal sm:text-[2.6rem] md:text-[3rem]">
                Owners who want to leave it <em className="text-bronze">better than they found it.</em>
              </h2>
            </Reveal>
            <Reveal delay={0.2}>
              <p className="mt-6 max-w-md text-[1.05rem] leading-relaxed text-charcoal/85">
                You&rsquo;ve probably had a conversation or two that felt more
                like a pitch than a partnership. We prefer to earn the
                relationship the other way, by being useful before we&rsquo;re
                hired.
              </p>
            </Reveal>

            <Reveal delay={0.3}>
              <ul className="mt-10 space-y-4">
                {items.map((it, i) => (
                  <li key={it} className="flex items-baseline gap-4 border-b border-border pb-4">
                    <span className="font-serif text-[0.78rem] italic text-bronze">
                      {String(i + 1).padStart(2, "0")}
                    </span>
                    <span className="font-serif text-[1.15rem] text-charcoal">{it}</span>
                  </li>
                ))}
              </ul>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ---------- Section: Meet Reif ---------- */

function MeetReif() {
  return (
    <section id="meet" className="relative mt-40 bg-cream-deep py-32 md:mt-56 md:py-44">
      <div className="mx-auto max-w-[1320px] px-6 md:px-10">
        <div className="grid grid-cols-12 gap-10 lg:gap-16">
          <div className="col-span-12 lg:col-span-5">
            <Reveal>
              <p className="eyebrow">№ 004 · Who We Are</p>
            </Reveal>
            <Reveal delay={0.1}>
              <h2 className="mt-6 font-serif text-[2.2rem] leading-[1.05] tracking-tight text-charcoal sm:text-[2.6rem] md:text-[3rem]">
                Years inside operating businesses <br />
                <em className="text-bronze">before a deal table.</em>
              </h2>
            </Reveal>
          </div>

          <div className="col-span-12 lg:col-span-7">
            <Reveal>
              <EngravingFrame
                src={reifPortrait}
                alt="Portrait of Reif, founder of Good + Co."
                aspect="4 / 5"
                caption="Reif. Operator first, advisor second."
                index="Plate IV · The Practitioner"
              />
            </Reveal>
          </div>
        </div>

        <div className="mt-16 grid grid-cols-12 gap-10">
          <div className="col-span-12 lg:col-span-7 lg:col-start-6">
            <Reveal>
              <div className="space-y-6 text-[1.1rem] leading-relaxed text-charcoal">
                <p>
                  Reif came up through operations, fixing systems, building
                  teams, making companies work better from the inside. That
                  shapes everything about how we look at a sale.
                </p>
                <p className="text-muted-foreground">
                  A business that holds up in diligence is a different thing
                  than a business that looks good in a pitch book.
                </p>
                <p>
                  We prepare for the first test, because that&rsquo;s the one
                  that matters.
                </p>
              </div>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ---------- Section: Readiness (3 cards) ---------- */

function Readiness() {
  const cards = [
    {
      n: "I",
      title: "Owner dependency",
      body: "If the business runs because of you, a buyer will price that risk. Building the leadership depth and operational structure that makes a company transferable takes time, more than most people expect, and more than a live process allows.",
      cue: "Harbor crew coordinating ropes. No single hero on deck.",
    },
    {
      n: "II",
      title: "Financial clarity",
      body: "Inconsistent reporting creates doubt in a buyer’s mind, and doubt is expensive. The goal is a financial narrative a buyer can follow and trust.",
      cue: "Compass, parallel rulers, logbook, navigation chart.",
    },
    {
      n: "III",
      title: "Revenue confidence",
      body: "Buyers want to believe the customers stay after you leave. The relationships and systems that make that case believable are built long before anyone signs an LOI.",
      cue: "Ship continuing through water after the lighthouse fades behind it.",
    },
  ];

  return (
    <section id="readiness" className="relative mt-40 md:mt-56">
      <div className="mx-auto max-w-[1320px] px-6 md:px-10">
        <div className="grid grid-cols-12 gap-10">
          <div className="col-span-12 lg:col-span-7">
            <Reveal>
              <p className="eyebrow">№ 005 · What Readiness Means</p>
            </Reveal>
            <Reveal delay={0.1}>
              <h2 className="mt-6 font-serif text-[2.2rem] leading-[1.05] tracking-tight text-charcoal sm:text-[2.8rem] md:text-[3.4rem]">
                Your company can stand on its own <em className="text-bronze">before a buyer tests it.</em>
              </h2>
            </Reveal>
          </div>
          <div className="col-span-12 lg:col-span-5">
            <Reveal delay={0.2}>
              <p className="text-[1.05rem] leading-relaxed text-charcoal/85">
                Three things tend to break in a transaction, and none of them
                are surprises.
              </p>
              <p className="mt-4 font-serif text-[1.2rem] italic text-charcoal">
                Each of them is a problem of time, not talent.
              </p>
            </Reveal>
          </div>
        </div>

        <Reveal delay={0.15}>
          <div className="mt-16">
            <EngravingFrame
              src={safePassageImg}
              imageClassName="drift-water"
              alt="A lighthouse beam illuminating a narrow safe passage between rocks"
              aspect="21 / 9"
              caption="The beam does not move the rocks. It shows the channel."
              index="Plate V · The Channel"
            />
          </div>
        </Reveal>

        <div className="mt-20 grid grid-cols-1 gap-px bg-border lg:grid-cols-3">
          {cards.map((c, i) => (
            <Reveal key={c.n} delay={i * 0.12}>
              <article className="flex h-full flex-col bg-cream p-8 md:p-10">
                <div className="flex items-baseline justify-between">
                  <span className="font-serif text-[2rem] italic text-bronze">{c.n}</span>
                  <span className="text-[0.65rem] uppercase tracking-[0.25em] text-muted-foreground">
                    Readiness
                  </span>
                </div>
                <div className="mt-8 h-px w-12 bg-bronze" />
                <h3 className="mt-6 font-serif text-[1.5rem] leading-[1.2] text-charcoal">
                  {c.title}
                </h3>
                <p className="mt-5 text-[0.98rem] leading-relaxed text-charcoal/80">
                  {c.body}
                </p>
                <p className="mt-8 border-t border-border pt-5 font-serif text-sm italic text-muted-foreground">
                  {c.cue}
                </p>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------- Section: Human Transition ---------- */

function HumanTransition() {
  return (
    <section className="relative mt-40 md:mt-56">
      <div className="mx-auto max-w-[1320px] px-6 md:px-10">
        <Reveal>
          <EngravingFrame
            src={harborImg}
            imageClassName="drift-water"
            alt="A ship entering harbor at sunrise with calm water and lifting fog"
            aspect="21 / 9"
            caption="Tuesday morning, after the closing."
            index="Plate VI · Landfall"
          />
        </Reveal>

        <div className="mt-16 grid grid-cols-12 gap-10">
          <div className="col-span-12 lg:col-span-6">
            <Reveal>
              <p className="eyebrow">№ 006 · After the Deal</p>
            </Reveal>
            <Reveal delay={0.1}>
              <h2 className="mt-6 font-serif text-[2.2rem] leading-[1.05] tracking-tight text-charcoal sm:text-[2.6rem] md:text-[3.2rem]">
                Most exit conversations focus on valuation. Few focus on{" "}
                <em className="text-bronze">the Tuesday morning after closing.</em>
              </h2>
            </Reveal>
          </div>
          <div className="col-span-12 lg:col-span-6">
            <Reveal delay={0.2}>
              <div className="space-y-5 text-[1.05rem] leading-relaxed text-charcoal/85">
                <p>
                  Owners who have been building for twenty years often find
                  that what they wanted wasn&rsquo;t simply an exit. They
                  wanted freedom, or stability, or time with their family, or
                  a new problem worth solving. Sometimes all of those at once.
                </p>
                <p>
                  The structure of a deal should serve that answer. So should
                  the relationship you choose to guide it.
                </p>
                <p className="font-serif text-[1.25rem] italic text-charcoal">
                  We stay in the conversation past the close.
                </p>
              </div>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ---------- Section: Mission ---------- */

function Mission() {
  return (
    <section id="mission" className="relative mt-40 bg-cream-deep py-32 md:mt-56 md:py-44">
      <div className="mx-auto max-w-[1320px] px-6 md:px-10">
        <div className="grid grid-cols-12 gap-10 lg:gap-16">
          <div className="col-span-12 lg:col-span-6">
            <Reveal>
              <EngravingFrame
                src={townImg}
                imageClassName="drift-sky"
                alt="A coastal town at dusk beneath a tall lighthouse with small lights in the homes"
                aspect="16 / 11"
                caption="A prepared community keeps its lights through the night."
                index="Plate VII · The Harbor Town"
              />
            </Reveal>
          </div>

          <div className="col-span-12 lg:col-span-6">
            <Reveal>
              <p className="eyebrow">№ 007 · Mission</p>
            </Reveal>
            <Reveal delay={0.1}>
              <h2 className="mt-6 font-serif text-[2.2rem] leading-[1.05] tracking-tight text-charcoal sm:text-[2.6rem] md:text-[3.2rem]">
                Strong businesses and strong communities are{" "}
                <em className="text-bronze">built the same way.</em>
              </h2>
            </Reveal>
            <Reveal delay={0.2}>
              <div className="mt-8 space-y-5 text-[1.05rem] leading-relaxed text-charcoal/85">
                <p>
                  Good + Co. is owned by The Good Project, a nonprofit
                  humanitarian organization. Profits from this practice support
                  disaster readiness work, helping communities build the
                  infrastructure they need before a crisis arrives.
                </p>
                <p>
                  Through real systems, real preparation, and real
                  relationships, put in place before they&rsquo;re needed.
                </p>
              </div>
            </Reveal>
            <Reveal delay={0.3}>
              <a
                href="#"
                className="mt-10 inline-flex items-center gap-3 border-b border-bronze/60 pb-1 text-[0.8rem] uppercase tracking-[0.22em] text-bronze hover:border-bronze"
              >
                Learn about The Good Project
                <span>→</span>
              </a>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ---------- Section: Final CTA ---------- */

function FinalCTA() {
  return (
    <section id="contact" className="relative mt-0 overflow-hidden bg-ink text-cream">
      <img
        src={beamImg}
        alt=""
        aria-hidden="true"
        loading="lazy"
        className="absolute inset-0 h-full w-full object-cover opacity-70 drift-sky"
      />
      <div className="absolute inset-0 bg-gradient-to-r from-ink via-ink/80 to-transparent" />
      <div className="relative mx-auto grid max-w-[1320px] grid-cols-12 gap-10 px-6 py-32 md:px-10 md:py-44 lg:py-56">
        <div className="col-span-12 lg:col-span-8">
          <Reveal>
            <p className="text-[0.72rem] uppercase tracking-[0.25em] text-bronze-soft">
              № 008 · A Direct Note
            </p>
          </Reveal>
          <Reveal delay={0.1}>
            <h2 className="mt-8 font-serif text-[2.4rem] leading-[1.05] tracking-tight sm:text-[3.2rem] md:text-[4.4rem]">
              You don&rsquo;t need a pitch. <br />
              You need <em className="text-bronze-soft">an honest conversation.</em>
            </h2>
          </Reveal>
          <Reveal delay={0.2}>
            <p className="mt-8 max-w-xl text-[1.05rem] leading-relaxed text-cream/80">
              If you&rsquo;re thinking about a transition in the next one to
              five years, the most useful thing we can offer right now is a
              clear picture of where you actually stand. What&rsquo;s working,
              what a buyer will find, and what you&rsquo;d want to change if you
              had the time to change it.
            </p>
          </Reveal>
          <Reveal delay={0.3}>
            <div className="mt-12 flex flex-col gap-6 sm:flex-row sm:items-center">
              <a
                href="mailto:hello@goodandco.com"
                className="group inline-flex items-center justify-between gap-6 bg-cream px-8 py-5 text-[0.72rem] uppercase tracking-[0.22em] text-ink transition-colors hover:bg-bronze hover:text-cream"
              >
                Start there
                <span className="text-bronze transition-transform group-hover:translate-x-1 group-hover:text-cream">→</span>
              </a>
              <p className="font-serif text-[1.05rem] italic text-cream/70">
                No cost. No pressure. One hour.
              </p>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
